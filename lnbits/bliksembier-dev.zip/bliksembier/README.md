# LNURLDevice - <small>[LNbits](https://github.com/lnbits/lnbits) extension</small>
<small>For more about LNBits extension check [this tutorial](https://github.com/lnbits/lnbits/wiki/LNbits-Extensions)</small>

For offline LNURL devices

`Author: Ben Arc` `Author: DNI`
